# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rotsim2d', 'rotsim2d.angular']

package_data = \
{'': ['*']}

install_requires = \
['anytree>=2.8.0,<3.0.0',
 'numpy>=1.20.1,<2.0.0',
 'pywigxjpf @ git+ssh://git@gitlab.com/allisonlab/mdcs/pywigxjpf.git@master',
 'scipy>=1.6.2,<2.0.0',
 'shed @ git+ssh://git@gitlab.com/allisonlab/mdcs/shed.git@master',
 'spectroscopy @ '
 'git+ssh://git@gitlab.com/allisonlab/mdcs/spectroscopy.git@master',
 'sympy>=1.8,<2.0']

extras_require = \
{'doc': ['Sphinx>=3.5.4,<4.0.0',
         'sphinx-rtd-theme>=0.5.2,<0.6.0',
         'numpydoc>=1.1.0,<2.0.0'],
 'interactive': ['matplotlib>=3.3.4,<4.0.0',
                 'ipython>=7.21.0,<8.0.0',
                 'PyQt5>=5.15.4,<6.0.0']}

setup_kwargs = {
    'name': 'rotsim2d',
    'version': '0.1.0',
    'description': 'Simulate 2D rovibrational spectra of gas-phase molecular samples',
    'long_description': "Package to simulate 2D rovibrational spectra of gas-phase samples.\n\nSee examples in `examples` directory:\n- `methyl_chloride/classify_pathways.py` prints out a mapping between\n  polarization-dependence expressions and pathways they correspond to. Modify\n  `gen_pathways` call to obtain classifications for different experimental\n  schemes.\n- `methyl_chloride/peak_picker_three_color.py` and\n  `methyl_chloride/peak_picker_three_color.py` allow one to inspect 2D peak\n  scatter plots. Clicking on a peak prints out double-sided Feynmann diagrams\n  that contribute to the selected peak. See comments in the code to modify what\n  gets plotted.\n- `methyl_chloride/polarization_dependence.py` allows one to inspect\n  polarization dependece in the case wher two beam polarizations are the same\n  and in the case when all polarizations are different. See comments in the code\n  to modify the suppressed pathways and excitation scheme.\n\n# Dependencies\n- numpy, scipy, anytree, sympy\n- [pywigxjpf](https://gitlab.com/allisonlab/mdcs/pywigxjpf)\n- [shed](https://gitlab.com/allisonlab/mdcs/shed)\n- [spectroscopy](https://gitlab.com/allisonlab/mdcs/spectroscopy)\n\n# Installation\nInstall the package by downloading or cloning the repo and calling the following inside main repository directory (containing `setup.py`):\n\n``` sh\npython -m pip install -e .\n```\n\nor by installing directly from the repo with pip\n\n``` sh\npython -m pip install git+ssh://git@gitlab.com/allisonlab/mdcs/rotsim2d.git@symmetrictop\n```\n\n[spectroscopy](https://gitlab.com/allisonlab/mdcs/spectroscopy) package needs to\nbe initialized by executing `spectroscopy/scripts/initialize_dbs.py` script to\ndownload spectroscopic data and fill the local database.\n\n# TODO\n+ Refactor angular momentum code.\n\n## Speed up calculations\n+ Use explicit formulas for G-factors instead of calculating Wigner coefficients numerically.\n+ Transform the problem into n-dimensional array calculations.\n+ Parallelize the code. Orders of magnitude improvement is needed, this won't be fast enough on its own.\n+ Translate the code to C++. *Profile first.*\n+ ~~Calculate only for initial ket excitation.~~\n+ ~~Calculate directly in the frequency domain. This is not a general solution, can't be done if pulse-shape effects are included or dephasing function does not have analytical Fourier transform.~~\n\n## Functionality\n\n+ Make time-domain and frequency-domain results agree.\n+ Constants.\n+ Add symmetric top and physical model.\n+ Add line-mixing (proper dephasing) and Doppler.\n+ Generate real spectra (relative to linear absorption).\n+ ~~Extract coherences and positions.~~\n+ ~~Polarization and rotational coherence.~~\n+ ~~Look at signals for different T_w times.~~ \n+ ~~Compare w/ overtones and wo/ overtones.~~\n+ ~~Improve graph export.~~\n+ ~~Add interstate coherences.~~\n+ ~~Add filtering of pathways: k-vectors.~~\n",
    'author': 'Grzegorz Kowzan',
    'author_email': 'grzegorz@kowzan.eu',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://gitlab.com/allisonlab/mdcs/rotsim2d',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.7,<3.10',
}


setup(**setup_kwargs)
